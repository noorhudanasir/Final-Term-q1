﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using question_01_Final_Term_2020.Models;

namespace question_01_Final_Term_2020.Controllers
{
    public class Online_transactionController : Controller
    {
        private Database1Entities db = new Database1Entities();

        // GET: Online_transaction
        public ActionResult Index()
        {
            return View(db.Online_transactions.ToList());
        }

        // GET: Online_transaction/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Online_transaction online_transaction = db.Online_transactions.Find(id);
            if (online_transaction == null)
            {
                return HttpNotFound();
            }
            return View(online_transaction);
        }

        // GET: Online_transaction/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Online_transaction/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Tranction_date,Tranction_type,Transaction_amount")] Online_transaction online_transaction)
        {
            if (ModelState.IsValid)
            {
                db.Online_transactions.Add(online_transaction);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(online_transaction);
        }

        // GET: Online_transaction/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Online_transaction online_transaction = db.Online_transactions.Find(id);
            if (online_transaction == null)
            {
                return HttpNotFound();
            }
            return View(online_transaction);
        }

        // POST: Online_transaction/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Tranction_date,Tranction_type,Transaction_amount")] Online_transaction online_transaction)
        {
            if (ModelState.IsValid)
            {
                db.Entry(online_transaction).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(online_transaction);
        }

        // GET: Online_transaction/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Online_transaction online_transaction = db.Online_transactions.Find(id);
            if (online_transaction == null)
            {
                return HttpNotFound();
            }
            return View(online_transaction);
        }

        // POST: Online_transaction/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Online_transaction online_transaction = db.Online_transactions.Find(id);
            db.Online_transactions.Remove(online_transaction);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
